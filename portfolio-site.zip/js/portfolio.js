const search = document.querySelector('#project-search');
if (search) {
    const cards = [...document.querySelectorAll('[data-search]')];
    const count = document.querySelector('#project-count');
    const empty = document.querySelector('#no-results');
    search.addEventListener('input', () => {
        const query = search.value.trim().toLowerCase();
        let shown = 0;
        cards.forEach(card => {
            card.hidden = !card.dataset.search.includes(query);
            if (!card.hidden) shown++;
        });
        count.textContent = `${shown} ${document.documentElement.lang === 'ar' ? 'مشروع' : 'projects'}`;
        empty.hidden = shown !== 0;
    });
}

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
if (!reduceMotion.matches && 'IntersectionObserver' in window) {
    document.body.classList.add('motion-ready');
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.08 });
    document.querySelectorAll('.section-head, .project-card, .about-grid > div, .services article, .experience-row, .detail-meta, .detail-body, .contact .eyebrow, .contact-heading').forEach((element, index) => {
        element.classList.add('reveal');
        element.style.setProperty('--reveal-delay', `${(index % 2) * 90}ms`);
        observer.observe(element);
    });
    const progress = document.createElement('div');
    progress.className = 'scroll-progress';
    progress.setAttribute('aria-hidden', 'true');
    document.body.append(progress);
    let scrollPending = false;
    const updateProgress = () => {
        const distance = document.documentElement.scrollHeight - window.innerHeight;
        progress.style.transform = `scaleX(${distance > 0 ? window.scrollY / distance : 0})`;
        scrollPending = false;
    };
    window.addEventListener('scroll', () => {
        if (!scrollPending) {
            scrollPending = true;
            requestAnimationFrame(updateProgress);
        }
    }, { passive: true });
    updateProgress();
    if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
        document.querySelectorAll('.project-visual, .hero-art').forEach(element => {
            let pointerFrame;
            element.addEventListener('pointermove', event => {
                cancelAnimationFrame(pointerFrame);
                pointerFrame = requestAnimationFrame(() => {
                    const rect = element.getBoundingClientRect();
                    const x = (event.clientX - rect.left) / rect.width;
                    const y = (event.clientY - rect.top) / rect.height;
                    element.style.setProperty('--spot-x', `${x * 100}%`);
                    element.style.setProperty('--spot-y', `${y * 100}%`);
                    element.style.setProperty('--light-x', `${x * 100}%`);
                    element.style.setProperty('--light-y', `${y * 100}%`);
                    element.style.setProperty('--tilt-x', `${(0.5 - y) * 5}deg`);
                    element.style.setProperty('--tilt-y', `${(x - 0.5) * 5}deg`);
                });
            });
            element.addEventListener('pointerleave', () => {
                cancelAnimationFrame(pointerFrame);
                element.style.setProperty('--tilt-x', '0deg');
                element.style.setProperty('--tilt-y', '0deg');
            });
        });
    }
}
