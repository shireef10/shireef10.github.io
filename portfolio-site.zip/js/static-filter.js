const form = document.querySelector('.filters');
if (form) {
  const search = document.querySelector('#project-search');
  const category = document.querySelector('#category');
  const cards = [...document.querySelectorAll('.archive-grid .project-card')];
  const count = document.querySelector('#project-count');
  const empty = document.querySelector('#no-results');
  const apply = () => {
    const query = search.value.trim().toLowerCase();
    let shown = 0;
    cards.forEach(card => {
      const technology = card.querySelector('.tag').textContent.trim();
      card.hidden = !card.dataset.search.includes(query) || (category.value !== '' && technology !== category.value);
      if (!card.hidden) shown++;
    });
    count.textContent = `${shown} ${document.documentElement.lang === 'ar' ? 'مشروع' : 'projects'}`;
    empty.hidden = shown !== 0;
  };
  category.value = new URLSearchParams(location.search).get('category') || '';
  form.addEventListener('submit', event => {
    event.preventDefault();
    const url = new URL(location.href);
    if (category.value) url.searchParams.set('category', category.value);
    else url.searchParams.delete('category');
    history.replaceState(null, '', url);
    apply();
  });
  search.addEventListener('input', apply);
  category.addEventListener('change', apply);
  apply();
}
